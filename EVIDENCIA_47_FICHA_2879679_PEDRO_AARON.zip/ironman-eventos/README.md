# **Pasos para probarlo**

* Abre el archivo `index.html` en tu navegador (haz doble clic o arrástralo al navegador)
* Usa las credenciales de prueba: usuario `admin` y contraseña `admin123`
