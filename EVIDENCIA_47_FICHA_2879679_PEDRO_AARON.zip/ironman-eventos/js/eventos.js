// eventos.js - Manejo de eventos

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('eventsTable')) {
        // Datos de ejemplo (en un sistema real, estos vendrían de una API)
        const eventos = [
            { id: 1, nombre: 'Ironman Barcelona', fecha: '2023-10-15', ubicacion: 'Barcelona, España', distancia: 226.2, estado: 'active' },
            { id: 2, nombre: 'Ironman Mallorca', fecha: '2023-05-20', ubicacion: 'Mallorca, España', distancia: 226.2, estado: 'completed' },
            { id: 3, nombre: 'Ironman Portugal', fecha: '2024-04-10', ubicacion: 'Cascais, Portugal', distancia: 226.2, estado: 'planning' }
        ];
        
        // Cargar tabla de eventos
        const eventsTable = document.getElementById('eventsTable').getElementsByTagName('tbody')[0];
        
        eventos.forEach(evento => {
            const row = eventsTable.insertRow();
            
            row.innerHTML = `
                <td>${evento.nombre}</td>
                <td>${formatDate(evento.fecha)}</td>
                <td>${evento.ubicacion}</td>
                <td>${evento.distancia} km</td>
                <td><span class="status ${evento.estado}">${getStatusText(evento.estado)}</span></td>
                <td>
                    <button class="btn btn-small edit-btn" data-id="${evento.id}">Editar</button>
                    <button class="btn btn-small delete-btn" data-id="${evento.id}">Eliminar</button>
                </td>
            `;
        });
        
        // Modal para agregar/editar evento
        const modal = document.getElementById('eventModal');
        const addEventBtn = document.getElementById('addEventBtn');
        const closeBtn = document.querySelector('.close');
        const eventForm = document.getElementById('eventForm');
        
        addEventBtn.addEventListener('click', function() {
            document.getElementById('modalTitle').textContent = 'Nuevo Evento';
            document.getElementById('eventId').value = '';
            eventForm.reset();
            modal.style.display = 'block';
        });
        
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
        
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        // Delegación de eventos para botones editar/eliminar
        eventsTable.addEventListener('click', function(e) {
            if (e.target.classList.contains('edit-btn')) {
                const eventId = e.target.getAttribute('data-id');
                editEvent(eventId);
            }
            
            if (e.target.classList.contains('delete-btn')) {
                const eventId = e.target.getAttribute('data-id');
                if (confirm('¿Estás seguro de eliminar este evento?')) {
                    deleteEvent(eventId);
                }
            }
        });
        
        // Manejar envío del formulario
        eventForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveEvent();
        });
    }
});

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
}

function getStatusText(status) {
    const statusText = {
        planning: 'Planificación',
        active: 'Activo',
        completed: 'Completado',
        cancelled: 'Cancelado'
    };
    return statusText[status] || status;
}

function editEvent(eventId) {
    // En un sistema real, buscaríamos el evento por ID
    console.log(`Editando evento con ID: ${eventId}`);
    
    // Simulamos que encontramos el evento
    const evento = {
        id: eventId,
        nombre: 'Ironman Barcelona',
        fecha: '2023-10-15',
        ubicacion: 'Barcelona, España',
        distancia: 226.2,
        estado: 'active'
    };
    
    document.getElementById('modalTitle').textContent = 'Editar Evento';
    document.getElementById('eventId').value = evento.id;
    document.getElementById('eventName').value = evento.nombre;
    document.getElementById('eventDate').value = evento.fecha;
    document.getElementById('eventLocation').value = evento.ubicacion;
    document.getElementById('eventDistance').value = evento.distancia;
    document.getElementById('eventStatus').value = evento.estado;
    
    document.getElementById('eventModal').style.display = 'block';
}

function deleteEvent(eventId) {
    console.log(`Eliminando evento con ID: ${eventId}`);
    // Aquí iría la lógica para eliminar el evento
    alert(`Evento ${eventId} eliminado (simulado)`);
    // Recargar la tabla o eliminar la fila
}

function saveEvent() {
    const eventId = document.getElementById('eventId').value;
    const isNew = eventId === '';
    
    const evento = {
        nombre: document.getElementById('eventName').value,
        fecha: document.getElementById('eventDate').value,
        ubicacion: document.getElementById('eventLocation').value,
        distancia: parseFloat(document.getElementById('eventDistance').value),
        estado: document.getElementById('eventStatus').value
    };
    
    console.log(isNew ? 'Creando nuevo evento:' : 'Actualizando evento:', evento);
    
    // Aquí iría la lógica para guardar en la API
    
    alert(`Evento ${isNew ? 'creado' : 'actualizado'} correctamente (simulado)`);
    document.getElementById('eventModal').style.display = 'none';
    
    // En un sistema real, recargaríamos los datos de la tabla
}