// participantes.js - Manejo de participantes

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('participantsTable')) {
        // Datos de ejemplo
        const participantes = [
            { id: 1, nombre: 'Juan Pérez', email: 'juan@example.com', edad: 32, genero: 'male', evento: 'Ironman Barcelona' },
            { id: 2, nombre: 'María García', email: 'maria@example.com', edad: 28, genero: 'female', evento: 'Ironman Mallorca' },
            { id: 3, nombre: 'Carlos López', email: 'carlos@example.com', edad: 35, genero: 'male', evento: 'Ironman Portugal' }
        ];
        
        // Datos de eventos para el filtro
        const eventos = [
            { id: 1, nombre: 'Ironman Barcelona' },
            { id: 2, nombre: 'Ironman Mallorca' },
            { id: 3, nombre: 'Ironman Portugal' }
        ];
        
        // Cargar filtro de eventos
        const eventFilter = document.getElementById('eventFilter');
        eventos.forEach(evento => {
            const option = document.createElement('option');
            option.value = evento.id;
            option.textContent = evento.nombre;
            eventFilter.appendChild(option);
        });
        
        // Cargar tabla de participantes
        loadParticipantsTable(participantes);
        
        // Modal para agregar/editar participante
        const modal = document.getElementById('participantModal');
        const addParticipantBtn = document.getElementById('addParticipantBtn');
        const closeBtn = modal.querySelector('.close');
        const participantForm = document.getElementById('participantForm');
        
        // Cargar eventos en el modal
        const participantEventSelect = document.getElementById('participantEvent');
        eventos.forEach(evento => {
            const option = document.createElement('option');
            option.value = evento.id;
            option.textContent = evento.nombre;
            participantEventSelect.appendChild(option);
        });
        
        addParticipantBtn.addEventListener('click', function() {
            document.getElementById('modalTitle').textContent = 'Nuevo Participante';
            document.getElementById('participantId').value = '';
            participantForm.reset();
            modal.style.display = 'block';
        });
        
        closeBtn.addEventListener('click', function() {
            modal.style.display = 'none';
        });
        
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
        
        // Manejar envío del formulario
        participantForm.addEventListener('submit', function(e) {
            e.preventDefault();
            saveParticipant();
        });
        
        // Filtros
        eventFilter.addEventListener('change', function() {
            filterParticipants();
        });
        
        document.getElementById('searchParticipant').addEventListener('input', function() {
            filterParticipants();
        });
    }
});

function loadParticipantsTable(participantes) {
    const table = document.getElementById('participantsTable').getElementsByTagName('tbody')[0];
    table.innerHTML = '';
    
    participantes.forEach(participante => {
        const row = table.insertRow();
        
        row.innerHTML = `
            <td>${participante.id}</td>
            <td>${participante.nombre}</td>
            <td>${participante.email}</td>
            <td>${participante.edad}</td>
            <td>${participante.genero === 'male' ? 'Masculino' : 'Femenino'}</td>
            <td>${participante.evento}</td>
            <td>
                <button class="btn btn-small edit-btn" data-id="${participante.id}">Editar</button>
                <button class="btn btn-small delete-btn" data-id="${participante.id}">Eliminar</button>
            </td>
        `;
    });
}

function filterParticipants() {
    // En un sistema real, haríamos una llamada a la API con los filtros
    console.log('Filtrando participantes...');
}

function editParticipant(participantId) {
    console.log(`Editando participante con ID: ${participantId}`);
    // Lógica similar a editEvent()
}

function deleteParticipant(participantId) {
    console.log(`Eliminando participante con ID: ${participantId}`);
    // Lógica similar a deleteEvent()
}

function saveParticipant() {
    console.log('Guardando participante...');
    // Lógica similar a saveEvent()
}