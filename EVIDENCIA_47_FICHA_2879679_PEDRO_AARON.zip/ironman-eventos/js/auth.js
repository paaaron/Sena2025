// auth.js - Manejo de autenticación

document.addEventListener('DOMContentLoaded', function() {
    // Verificar si estamos en la página de login
    if (document.getElementById('loginForm')) {
        const loginForm = document.getElementById('loginForm');
        
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            
            // Aquí iría la lógica real de autenticación
            if (username === 'admin' && password === 'admin123') {
                // Guardar en sessionStorage
                sessionStorage.setItem('authenticated', 'true');
                sessionStorage.setItem('username', username);
                
                // Redirigir al dashboard
                window.location.href = 'dashboard.html';
            } else {
                document.getElementById('loginError').textContent = 'Usuario o contraseña incorrectos';
            }
        });
    }
    
    // Verificar autenticación en otras páginas
    if (document.getElementById('logoutBtn')) {
        const authenticated = sessionStorage.getItem('authenticated');
        
        if (!authenticated || authenticated !== 'true') {
            window.location.href = 'index.html';
        }
        
        // Mostrar nombre de usuario
        const username = sessionStorage.getItem('username');
        if (username && document.getElementById('usernameDisplay')) {
            document.getElementById('usernameDisplay').textContent = username;
        }
        
        // Manejar logout
        document.getElementById('logoutBtn').addEventListener('click', function() {
            sessionStorage.removeItem('authenticated');
            sessionStorage.removeItem('username');
            window.location.href = 'index.html';
        });
    }
});