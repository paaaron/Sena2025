// resultados.js - Manejo de resultados

document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('resultEventFilter')) {
        // Datos de eventos para el filtro
        const eventos = [
            { id: 1, nombre: 'Ironman Barcelona 2023', fecha: '2023-10-15', ubicacion: 'Barcelona, España' },
            { id: 2, nombre: 'Ironman Mallorca 2023', fecha: '2023-05-20', ubicacion: 'Mallorca, España' },
            { id: 3, nombre: 'Ironman Portugal 2022', fecha: '2022-04-10', ubicacion: 'Cascais, Portugal' }
        ];
        
        // Cargar filtro de eventos
        const eventFilter = document.getElementById('resultEventFilter');
        eventos.forEach(evento => {
            const option = document.createElement('option');
            option.value = evento.id;
            option.textContent = evento.nombre;
            eventFilter.appendChild(option);
        });
        
        // Seleccionar el primer evento por defecto
        if (eventos.length > 0) {
            eventFilter.value = eventos[0].id;
            loadEventInfo(eventos[0]);
            loadResults(eventos[0].id);
        }
        
        // Manejar cambio de evento
        eventFilter.addEventListener('change', function() {
            const selectedEventId = parseInt(this.value);
            const selectedEvent = eventos.find(e => e.id === selectedEventId);
            
            if (selectedEvent) {
                loadEventInfo(selectedEvent);
                loadResults(selectedEventId);
            }
        });
        
        // Manejar cambio de categoría
        document.getElementById('resultCategoryFilter').addEventListener('change', function() {
            loadResults(parseInt(eventFilter.value));
        });
        
        // Manejar botón actualizar
        document.getElementById('refreshResults').addEventListener('click', function() {
            loadResults(parseInt(eventFilter.value));
        });
        
        // Manejar botón exportar
        document.getElementById('exportResults').addEventListener('click', function() {
            exportToExcel();
        });
        
        // Manejar pestañas
        const tabBtns = document.querySelectorAll('.tab-btn');
        tabBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                // Remover clase active de todos los botones
                tabBtns.forEach(b => b.classList.remove('active'));
                // Agregar clase active al botón clickeado
                this.classList.add('active');
                
                // Ocultar todos los contenidos
                document.querySelectorAll('.tab-content').forEach(content => {
                    content.classList.remove('active');
                });
                
                // Mostrar el contenido correspondiente
                const tabId = this.getAttribute('data-tab');
                document.getElementById(`${tabId}-tab`).classList.add('active');
            });
        });
    }
});

function loadEventInfo(evento) {
    document.getElementById('eventNameTitle').textContent = evento.nombre;
    document.getElementById('eventDateLocation').textContent = `${formatDate(evento.fecha)} - ${evento.ubicacion}`;
}

function loadResults(eventId) {
    console.log(`Cargando resultados para evento ID: ${eventId}`);
    
    // Datos de ejemplo
    const resultados = [
        { posicion: 1, numero: 101, nombre: 'Juan Pérez', categoria: 'M30-34', natacion: '00:45:30', ciclismo: '04:30:15', carrera: '03:15:45', total: '08:31:30' },
        { posicion: 2, numero: 205, nombre: 'María García', categoria: 'F25-29', natacion: '00:47:15', ciclismo: '04:35:20', carrera: '03:10:30', total: '08:33:05' },
        { posicion: 3, numero: 312, nombre: 'Carlos López', categoria: 'M35-39', natacion: '00:50:10', ciclismo: '04:25:45', carrera: '03:20:15', total: '08:36:10' }
    ];
    
    // Cargar tabla de resultados generales
    const table = document.getElementById('generalResultsTable').getElementsByTagName('tbody')[0];
    table.innerHTML = '';
    
    resultados.forEach(resultado => {
        const row = table.insertRow();
        
        row.innerHTML = `
            <td>${resultado.posicion}</td>
            <td>${resultado.numero}</td>
            <td>${resultado.nombre}</td>
            <td>${resultado.categoria}</td>
            <td>${resultado.natacion}</td>
            <td>${resultado.ciclismo}</td>
            <td>${resultado.carrera}</td>
            <td><strong>${resultado.total}</strong></td>
        `;
    });
}

function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
}

function exportToExcel() {
    console.log('Exportando a Excel...');
    alert('Función de exportación a Excel (simulada)');
}